"""Баптаулар. SERVER-ді config.ini немесе орта айнымалысымен ауыстыруға болады."""
import configparser
import os
import sys
from pathlib import Path

if getattr(sys, "frozen", False):
    HOME = Path(sys.executable).resolve().parent      # exe тұрған қалта
    RES = Path(getattr(sys, "_MEIPASS", HOME))        # exe ішіндегі ресурстар
else:
    HOME = RES = Path(__file__).resolve().parent.parent

DATABASE = "UniversityJournal"
SCHEMA_VERSION = "3"
SCRIPT_PATH = RES / "sql" / "schema.sql"

SERVER = r"localhost\SQLEXPRESS"
ADMIN_PASSWORD = "admin123"

_ini = HOME / "config.ini"
if _ini.exists():
    cp = configparser.ConfigParser()
    cp.read(_ini, encoding="utf-8")
    SERVER = cp.get("db", "server", fallback=SERVER)
    ADMIN_PASSWORD = cp.get("db", "admin_password", fallback=ADMIN_PASSWORD)
SERVER = os.environ.get("DB_SERVER", SERVER)
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", ADMIN_PASSWORD)

MIN_PASSWORD_LEN = 6
ATTENDANCE = ["Қатысты", "Қатыспады", "Себепті"]
DAYS = ["Дүйсенбі", "Сейсенбі", "Сәрсенбі", "Бейсенбі", "Жұма", "Сенбі"]
ROLE_LABELS = {"ADMIN": "Әкімші", "TEACHER": "Оқытушы", "STUDENT": "Студент"}
