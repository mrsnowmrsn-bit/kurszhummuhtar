"""SQL Server-мен жұмыс (pyodbc): қосылым, сұраныс, процедуралар, баптау."""
import re

import pyodbc

from app import config
from app.security import hash_password

DRIVERS = [
    "ODBC Driver 18 for SQL Server",
    "ODBC Driver 17 for SQL Server",
    "ODBC Driver 13 for SQL Server",
    "SQL Server Native Client 11.0",
    "SQL Server",  # Windows-та әрдайым бар ескі драйвер
]


def pick_driver() -> str:
    have = pyodbc.drivers()
    for name in DRIVERS:
        if name in have:
            return name
    raise RuntimeError("SQL Server ODBC драйвері табылмады.")


def conn_str(database: str) -> str:
    driver = pick_driver()
    s = (f"DRIVER={{{driver}}};SERVER={config.SERVER};DATABASE={database};"
         "Trusted_Connection=yes;")
    if "ODBC Driver" in driver:
        s += "TrustServerCertificate=yes;"
    return s


def split_batches(script: str) -> list:
    """SSMS сияқты GO жолдары бойынша бөледі."""
    parts = re.split(r"^\s*GO\s*$", script, flags=re.I | re.M)
    return [p.strip() for p in parts if p.strip()]


def friendly(e: Exception) -> str:
    """SQL Server қатесін түсінікті хабарға айналдырады."""
    text = str(e)
    m = re.search(r"\[SQL Server\](.*?)\s*\(\d+\)", text, re.S)
    msg = m.group(1).strip() if m else text
    low = msg.lower()
    if "unique" in low or "duplicate" in low:
        return "Мұндай жазба бұрыннан бар."
    if "reference constraint" in low or "foreign key" in low:
        return "Байланысты жазбалар бар, әрекетті орындау мүмкін емес."
    if "check constraint" in low:
        return "Енгізілген мән рұқсат етілген шектен тыс."
    return msg


class Database:
    def __init__(self):
        self.conn = None

    # ---- қосылым және баптау ----
    def ensure_ready(self):
        """Дерекқор мен объектілер жоқ болса, sql/schema.sql арқылы құрады."""
        master = pyodbc.connect(conn_str("master"), autocommit=True, timeout=10)
        try:
            need = True
            cur = master.cursor()
            if cur.execute("SELECT DB_ID(?)", config.DATABASE).fetchone()[0] is not None:
                try:
                    row = cur.execute(
                        f"SELECT meta_value FROM [{config.DATABASE}].dbo.app_meta"
                        " WHERE meta_key = N'schema_version'"
                    ).fetchone()
                    need = not (row and row[0] == config.SCHEMA_VERSION)
                except pyodbc.Error:
                    need = True
            if need:
                script = config.SCRIPT_PATH.read_text(encoding="utf-8")
                for batch in split_batches(script):
                    cur.execute(batch)
                    while cur.nextset():
                        pass
        finally:
            master.close()
        self.conn = pyodbc.connect(conn_str(config.DATABASE), autocommit=True, timeout=10)
        self._seed_admin()

    def _seed_admin(self):
        _, rows = self.query("SELECT COUNT(*) FROM dbo.users WHERE user_role = N'ADMIN'")
        if rows[0][0] == 0:
            self.call("sp_RegisterUser", "admin", hash_password(config.ADMIN_PASSWORD),
                      "Бас Администратор", "ADMIN", None, None)

    # ---- сұраныстар ----
    def query(self, sql: str, params=()):
        cur = self.conn.cursor()
        cur.execute(sql, params)
        cols = [c[0] for c in cur.description]
        rows = [tuple(r) for r in cur.fetchall()]
        return cols, rows

    def rows(self, sql: str, params=()) -> list:
        return self.query(sql, params)[1]

    def execute(self, sql: str, params=()):
        cur = self.conn.cursor()
        cur.execute(sql, params)
        while cur.nextset():
            pass

    def call(self, proc: str, *params):
        """Сақталатын процедураны шақырады, нәтиже жиынын (бар болса) қайтарады."""
        marks = ", ".join(["?"] * len(params))
        cur = self.conn.cursor()
        cur.execute(f"EXEC dbo.{proc} {marks}".strip(), params)
        result = None
        if cur.description:
            result = [tuple(r) for r in cur.fetchall()]
        while cur.nextset():
            pass
        return result

    def set_session_user(self, username):
        """Триггерлер аудитке кім өзгерткенін жазуы үшін."""
        try:
            self.execute("EXEC sp_set_session_context N'username', ?", (username,))
        except pyodbc.Error:
            pass  # аудитте SQL Server пайдаланушысы жазылады

    def backup(self) -> str:
        import datetime
        rows = self.rows("SELECT CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS NVARCHAR(260))")
        folder = rows[0][0]
        if not folder:
            raise RuntimeError("Сервердің backup қалтасы анықталмады.")
        name = f"UniversityJournal_{datetime.datetime.now():%Y%m%d_%H%M%S}.bak"
        path = folder.rstrip("\\") + "\\" + name
        self.call("sp_BackupDatabase", path)
        return path
