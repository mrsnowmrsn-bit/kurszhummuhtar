"""SQL есептер (T-SQL). Барлық сұраныс тұрақты: пайдаланушы мәтіні қосылмайды."""

REPORTS = [
    {
        "title": "Пәндер бойынша статистика",
        "concept": "GROUP BY, COUNT, AVG, MIN, MAX",
        "sql": """SELECT subject_name AS [Пән],
       COUNT(*) AS [Жазбалар],
       CAST(AVG(CAST(grade AS DECIMAL(5,2))) AS DECIMAL(5,1)) AS [Орташа],
       MIN(grade) AS [Мин],
       MAX(grade) AS [Макс]
FROM dbo.v_journal
WHERE grade IS NOT NULL
GROUP BY subject_name
ORDER BY AVG(CAST(grade AS DECIMAL(5,2))) DESC""",
    },
    {
        "title": "Топтар рейтингі (кемінде 3 жазбасы барлар)",
        "concept": "GROUP BY, HAVING, COUNT(DISTINCT)",
        "sql": """SELECT group_name AS [Топ],
       COUNT(DISTINCT student_id) AS [Студент],
       CAST(AVG(CAST(grade AS DECIMAL(5,2))) AS DECIMAL(5,1)) AS [Орташа баға]
FROM dbo.v_journal
WHERE grade IS NOT NULL
GROUP BY group_name
HAVING COUNT(*) >= 3
ORDER BY AVG(CAST(grade AS DECIMAL(5,2))) DESC""",
    },
    {
        "title": "Жалпы орташадан жоғары студенттер",
        "concept": "ішкі сұраныс (subquery), VIEW",
        "sql": """SELECT student_code AS [Код], full_name AS [Студент],
       group_name AS [Топ], avg_grade AS [Орташа баға]
FROM dbo.v_student_stats
WHERE avg_grade > (SELECT AVG(CAST(grade AS DECIMAL(5,2))) FROM dbo.grades)
ORDER BY avg_grade DESC""",
    },
    {
        "title": "Топ ішіндегі орын (рейтинг)",
        "concept": "оконная функция RANK() OVER (PARTITION BY ...)",
        "sql": """SELECT group_name AS [Топ], full_name AS [Студент],
       avg_grade AS [Орташа баға],
       RANK() OVER (PARTITION BY group_name ORDER BY avg_grade DESC) AS [Орын]
FROM dbo.v_student_stats
WHERE avg_grade IS NOT NULL
ORDER BY group_name, [Орын]""",
    },
    {
        "title": "Қатысу статистикасы топтар бойынша",
        "concept": "CASE WHEN, SUM, GROUP BY",
        "sql": """SELECT group_name AS [Топ],
       COUNT(*) AS [Сабақ],
       SUM(CASE WHEN attendance = N'Қатысты'   THEN 1 ELSE 0 END) AS [Қатысты],
       SUM(CASE WHEN attendance = N'Қатыспады' THEN 1 ELSE 0 END) AS [Қатыспады],
       CAST(100.0 * SUM(CASE WHEN attendance = N'Қатысты' THEN 1 ELSE 0 END)
            / COUNT(*) AS DECIMAL(5,1)) AS [Қатысу %]
FROM dbo.v_journal
GROUP BY group_name""",
    },
    {
        "title": "Үй тапсырмасын тапсырмағандар",
        "concept": "LEFT JOIN ... WHERE ... IS NULL (anti-join)",
        "sql": """SELECT st.full_name AS [Студент], g.group_name AS [Топ],
       h.title AS [Тапсырма], h.deadline AS [Мерзімі]
FROM dbo.homeworks h
JOIN dbo.students st     ON st.group_id = h.group_id
JOIN dbo.study_groups g  ON g.id = st.group_id
LEFT JOIN dbo.submissions sb
       ON sb.homework_id = h.id AND sb.student_id = st.id
WHERE sb.id IS NULL
ORDER BY h.deadline, g.group_name, st.full_name""",
    },
    {
        "title": "Айлық үлгерім динамикасы",
        "concept": "CTE (WITH), CONVERT, екі деңгейлі агрегация",
        "sql": """WITH monthly AS (
    SELECT LEFT(CONVERT(VARCHAR(10), lesson_date, 23), 7) AS ay,
           student_id,
           AVG(CAST(grade AS DECIMAL(5,2))) AS a
    FROM dbo.v_journal
    WHERE grade IS NOT NULL
    GROUP BY LEFT(CONVERT(VARCHAR(10), lesson_date, 23), 7), student_id
)
SELECT ay AS [Ай], COUNT(*) AS [Студент],
       CAST(AVG(a) AS DECIMAL(5,1)) AS [Орташа баға]
FROM monthly
GROUP BY ay
ORDER BY ay""",
    },
    {
        "title": "Академиялық қарыздар (баға < 50 немесе қатыспаған)",
        "concept": "WHERE ... OR, VIEW, сұрыптау",
        "sql": """SELECT student_code AS [Код], full_name AS [Студент], group_name AS [Топ],
       subject_name AS [Пән], grade AS [Баға], attendance AS [Қатысуы],
       lesson_date AS [Күні]
FROM dbo.v_journal
WHERE grade < 50 OR attendance = N'Қатыспады'
ORDER BY group_name, full_name, lesson_date""",
    },
]
