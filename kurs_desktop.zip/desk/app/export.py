"""Excel және PDF экспорты."""
import datetime
import decimal
import os


def _cell(v):
    if v is None:
        return ""
    if isinstance(v, decimal.Decimal):
        return float(v)
    if isinstance(v, (datetime.datetime, datetime.date)):
        return str(v)[:19] if isinstance(v, datetime.datetime) else str(v)
    return v


def export_excel(path: str, title: str, headers: list, rows: list):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    wb = Workbook()
    ws = wb.active
    ws.title = title[:30] or "Есеп"
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F4E79")
        c.alignment = Alignment(horizontal="center")
    for r in rows:
        ws.append([_cell(v) for v in r])
    for i, h in enumerate(headers, start=1):
        width = max([len(str(h))] + [len(str(_cell(r[i - 1]))) for r in rows[:200]]) + 2
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = min(width, 50)
    wb.save(path)


def _register_font() -> str:
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    candidates = [
        r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\segoeui.ttf",
        r"C:\Windows\Fonts\calibri.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for p in candidates:
        if os.path.exists(p):
            pdfmetrics.registerFont(TTFont("AppFont", p))
            return "AppFont"
    return "Helvetica"  # кирилл әріптері көрінбеуі мүмкін


def export_pdf(path: str, title: str, headers: list, rows: list):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    font = _register_font()
    cell = ParagraphStyle("cell", fontName=font, fontSize=8, leading=10)
    head = ParagraphStyle("head", fontName=font, fontSize=8, leading=10,
                          textColor=colors.white)
    h1 = ParagraphStyle("h1", fontName=font, fontSize=14, leading=18)

    def esc(v):
        return str(_cell(v)).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    data = [[Paragraph(esc(h), head) for h in headers]]
    for r in rows:
        data.append([Paragraph(esc(v), cell) for v in r])
    doc = SimpleDocTemplate(path, pagesize=landscape(A4), leftMargin=24, rightMargin=24,
                            topMargin=24, bottomMargin=24)
    table = Table(data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4E79")),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F6FA")]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    stamp = f"{datetime.datetime.now():%d.%m.%Y %H:%M}"
    doc.build([Paragraph(title, h1), Paragraph(stamp, cell), Spacer(1, 8), table])
