"""Барлық беттер (экрандар): әкімші, оқытушы және студент үшін."""
import datetime
import functools
from tkinter import messagebox

import customtkinter as ctk

from app import config
from app.theme import (ACCENTS, BORDER, CARD, DANGER, DANGER_HOVER, FONT, MUTED, PRIMARY,
                       PRIMARY_HOVER, SECONDARY, SECONDARY_HOVER, TEXT)
from app.reports import REPORTS
from app.security import hash_password
from app.widgets import (DataTable, FormDialog, confirm, export_buttons,
                         show_error, show_info)


def safe(fn):
    """Қате болса терезе көрсетіп, бағдарламаны құлатпайды."""
    @functools.wraps(fn)
    def wrapper(*a, **k):
        try:
            return fn(*a, **k)
        except Exception as e:
            show_error(e)
    return wrapper


def parse_date(s):
    try:
        return datetime.date.fromisoformat(s.strip())
    except ValueError:
        return None


class Page(ctk.CTkFrame):
    title = ""

    def __init__(self, master, app):
        super().__init__(master, fg_color="transparent")
        self.app, self.db, self.user = app, app.db, app.user
        self.role = app.user["role"]
        ctk.CTkLabel(self, text=self.title, text_color=TEXT, anchor="w",
                     font=ctk.CTkFont(family=FONT, size=26, weight="bold")).pack(fill="x", pady=(0, 12))
        self.build()
        self.reload()

    def build(self):
        pass

    @safe
    def reload(self):
        self.refresh()

    def refresh(self):
        pass

    # ---- көмекші құралдар ----
    def bar(self):
        f = ctk.CTkFrame(self, fg_color="transparent")
        f.pack(fill="x", pady=(0, 8))
        return f

    SECONDARY_WORDS = ("Өзгерту", "Жаңарту", "Оқу", "Сипаттама", "Пароль")

    def btn(self, bar, text, cmd, width=110, kind="auto", **kw):
        if kind == "auto":
            kind = ("danger" if "Жою" in text else
                    "secondary" if any(w in text for w in self.SECONDARY_WORDS) else "primary")
        fg, hv, tc = {"primary": (PRIMARY, PRIMARY_HOVER, "white"),
                      "danger": (DANGER, DANGER_HOVER, "white"),
                      "secondary": (SECONDARY, SECONDARY_HOVER, TEXT)}[kind]
        b = ctk.CTkButton(bar, text=text, width=width, height=34, corner_radius=8,
                          fg_color=fg, hover_color=hv, text_color=tc,
                          font=ctk.CTkFont(family=FONT, size=13), command=safe(cmd), **kw)
        b.pack(side="left", padx=4)
        return b

    def pick(self, table):
        row = table.selected()
        if not row:
            show_info("Алдымен кестеден жолды таңдаңыз.")
        return row

    def groups(self):
        return [(r[0], r[1]) for r in self.db.rows(
            "SELECT id, group_name FROM dbo.study_groups ORDER BY group_name")]

    def subjects(self):
        return [(r[0], r[1]) for r in self.db.rows(
            "SELECT id, subject_name FROM dbo.subjects ORDER BY subject_name")]

    def search_box(self, bar, table):
        e = ctk.CTkEntry(bar, placeholder_text="Іздеу...", width=220, height=34,
                         corner_radius=8, border_color=BORDER)
        e.pack(side="left", padx=4)
        e.bind("<KeyRelease>", lambda _e: table.apply(e.get()))
        return e

    def form(self, title, fields, on_submit, initial=None):
        FormDialog(self, title, fields, on_submit, initial)


# ======================= ӘКІМШІ =======================
class DashboardPage(Page):
    title = "Басқару панелі"

    def build(self):
        self._welcome = []
        self.cards = ctk.CTkFrame(self, fg_color="transparent")
        self.cards.pack(fill="x")

    def refresh(self):
        r = self.db.rows(
            "SELECT (SELECT COUNT(*) FROM dbo.students),"
            " (SELECT COUNT(*) FROM dbo.study_groups),"
            " (SELECT COUNT(*) FROM dbo.subjects),"
            " (SELECT CAST(AVG(CAST(grade AS DECIMAL(5,2))) AS DECIMAL(5,1)) FROM dbo.grades)")[0]
        for w in self.cards.winfo_children():
            w.destroy()
        for w in self._welcome:
            w.destroy()
        items = [("Студенттер", r[0]), ("Топтар", r[1]),
                 ("Пәндер", r[2]), ("Орташа баға", r[3] if r[3] is not None else 0)]
        for (t, v), color in zip(items, ACCENTS):
            c = ctk.CTkFrame(self.cards, corner_radius=14, fg_color=CARD, border_width=1,
                             border_color=BORDER, width=220, height=110)
            c.pack(side="left", padx=(0, 16), pady=6)
            c.pack_propagate(False)
            ctk.CTkFrame(c, width=6, corner_radius=3, fg_color=color).pack(
                side="left", fill="y", padx=(12, 0), pady=16)
            inner = ctk.CTkFrame(c, fg_color="transparent")
            inner.pack(side="left", fill="both", expand=True, padx=14, pady=14)
            ctk.CTkLabel(inner, text=t, text_color=MUTED, anchor="w",
                         font=ctk.CTkFont(family=FONT, size=13)).pack(fill="x")
            ctk.CTkLabel(inner, text=str(v), text_color=TEXT, anchor="w",
                         font=ctk.CTkFont(family=FONT, size=32, weight="bold")).pack(fill="x")
        lbl = ctk.CTkLabel(self, anchor="w", text_color=MUTED,
                           font=ctk.CTkFont(family=FONT, size=14),
                           text=f"Қош келдіңіз, {self.user['full_name']}. "
                                "Сол жақ мәзірден бөлімді таңдаңыз.")
        lbl.pack(fill="x", pady=(16, 0))
        self._welcome = [lbl]


class StudentsPage(Page):
    title = "Студенттер"

    def build(self):
        bar = self.bar()
        self.table = DataTable(self)
        self.search = self.search_box(bar, self.table)
        self.search.bind("<KeyRelease>", lambda _e: self.filter())
        self.gcombo = ctk.CTkComboBox(bar, values=["Барлық топ"], width=150, state="readonly",
                                      command=lambda _v: self.filter())
        self.gcombo.pack(side="left", padx=4)
        self.btn(bar, "Қосу", self.add)
        self.btn(bar, "Өзгерту", self.edit)
        self.btn(bar, "Жою", self.delete)
        export_buttons(bar, self.table, "Студенттер")
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        cols, rows = self.db.query(
            "SELECT s.id, s.group_id, s.student_code AS [Код], s.full_name AS [Аты-жөні],"
            " g.group_name AS [Топ], s.course_num AS [Курс],"
            " v.avg_grade AS [Орташа баға], v.attendance_pct AS [Қатысу %]"
            " FROM dbo.students s JOIN dbo.study_groups g ON g.id = s.group_id"
            " LEFT JOIN dbo.v_student_stats v ON v.student_id = s.id"
            " ORDER BY g.group_name, s.full_name")
        self.table.load(cols, rows, hidden=("id", "group_id"))
        self.gmap = {name: gid for gid, name in self.groups()}
        self.gcombo.configure(values=["Барлық топ"] + list(self.gmap))
        self.filter()

    def filter(self):
        g = self.gcombo.get()
        eq = ("group_id", self.gmap[g]) if g in self.gmap else None
        self.table.apply(self.search.get(), eq)

    def add(self):
        groups = self.groups()
        if not groups:
            return show_info("Алдымен топ қосыңыз.")

        def submit(v):
            if len(v["username"]) < 3 or not v["full_name"]:
                return "Логин (кемінде 3 таңба) мен аты-жөнін толтырыңыз."
            if len(v["password"]) < config.MIN_PASSWORD_LEN:
                return f"Пароль кемінде {config.MIN_PASSWORD_LEN} таңба болсын."
            self.db.call("sp_RegisterUser", v["username"], hash_password(v["password"]),
                         v["full_name"], "STUDENT", v["group"], v["course"])
            self.reload()
        self.form("Жаңа студент", [
            {"name": "username", "label": "Логин"},
            {"name": "password", "label": "Пароль", "kind": "password"},
            {"name": "full_name", "label": "Аты-жөні"},
            {"name": "group", "label": "Топ", "kind": "combo", "options": groups},
            {"name": "course", "label": "Курс", "kind": "combo",
             "options": [(i, str(i)) for i in range(1, 6)]},
        ], submit)

    def edit(self):
        row = self.pick(self.table)
        if not row:
            return

        def submit(v):
            if not v["full_name"]:
                return "Аты-жөнін толтырыңыз."
            self.db.call("sp_UpdateStudent", row["id"], v["full_name"], v["group"], v["course"])
            self.reload()
        self.form("Студентті өзгерту", [
            {"name": "full_name", "label": "Аты-жөні"},
            {"name": "group", "label": "Топ", "kind": "combo", "options": self.groups()},
            {"name": "course", "label": "Курс", "kind": "combo",
             "options": [(i, str(i)) for i in range(1, 6)]},
        ], submit, {"full_name": row["Аты-жөні"], "group": row["group_id"],
                    "course": row["Курс"]})

    def delete(self):
        row = self.pick(self.table)
        if row and confirm(f"{row['Аты-жөні']} студентін және оның бағаларын жою керек пе?"):
            self.db.call("sp_DeleteStudent", row["id"])
            self.reload()


class GroupsPage(Page):
    title = "Топтар"

    def build(self):
        bar = self.bar()
        self.table = DataTable(self)
        self.btn(bar, "Қосу", self.add)
        self.btn(bar, "Атын өзгерту", self.rename, width=140)
        self.btn(bar, "Жою", self.delete)
        export_buttons(bar, self.table, "Топтар")
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        cols, rows = self.db.query(
            "SELECT g.id, g.group_name AS [Топ], COUNT(s.id) AS [Студент саны]"
            " FROM dbo.study_groups g LEFT JOIN dbo.students s ON s.group_id = g.id"
            " GROUP BY g.id, g.group_name ORDER BY g.group_name")
        self.table.load(cols, rows, hidden=("id",))

    def add(self):
        def submit(v):
            if not v["name"]:
                return "Атауын жазыңыз."
            self.db.execute("INSERT INTO dbo.study_groups (group_name) VALUES (?)", (v["name"],))
            self.reload()
        self.form("Жаңа топ", [{"name": "name", "label": "Топ атауы (мысалы, ИС-302)"}], submit)

    def rename(self):
        row = self.pick(self.table)
        if not row:
            return

        def submit(v):
            if not v["name"]:
                return "Атауын жазыңыз."
            self.db.execute("UPDATE dbo.study_groups SET group_name = ? WHERE id = ?",
                            (v["name"], row["id"]))
            self.reload()
        self.form("Топ атауын өзгерту", [{"name": "name", "label": "Жаңа атауы"}],
                  submit, {"name": row["Топ"]})

    def delete(self):
        row = self.pick(self.table)
        if row and confirm(f"{row['Топ']} тобын жою керек пе? Кестесі мен тапсырмалары да жойылады."):
            try:
                self.db.execute("DELETE FROM dbo.study_groups WHERE id = ?", (row["id"],))
            except Exception:
                return show_info("Топта студенттер бар. Алдымен оларды басқа топқа ауыстырыңыз.")
            self.reload()


class SubjectsPage(Page):
    title = "Пәндер мен кредиттер"

    def build(self):
        bar = self.bar()
        self.table = DataTable(self)
        self.btn(bar, "Қосу", self.add)
        self.btn(bar, "Өзгерту", self.edit)
        self.btn(bar, "Жою", self.delete)
        export_buttons(bar, self.table, "Пәндер")
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        cols, rows = self.db.query(
            "SELECT id, subject_name AS [Пән], credits AS [Кредит]"
            " FROM dbo.subjects ORDER BY subject_name")
        self.table.load(cols, rows, hidden=("id",))

    def _fields(self):
        return [{"name": "name", "label": "Пән атауы"},
                {"name": "credits", "label": "Кредит (1-10)"}]

    def add(self):
        def submit(v):
            if not v["name"] or not v["credits"].isdigit():
                return "Атауы мен кредитті (сан) толтырыңыз."
            self.db.execute("INSERT INTO dbo.subjects (subject_name, credits) VALUES (?, ?)",
                            (v["name"], int(v["credits"])))
            self.reload()
        self.form("Жаңа пән", self._fields(), submit, {"credits": 3})

    def edit(self):
        row = self.pick(self.table)
        if not row:
            return

        def submit(v):
            if not v["name"] or not v["credits"].isdigit():
                return "Атауы мен кредитті (сан) толтырыңыз."
            self.db.execute("UPDATE dbo.subjects SET subject_name = ?, credits = ? WHERE id = ?",
                            (v["name"], int(v["credits"]), row["id"]))
            self.reload()
        self.form("Пәнді өзгерту", self._fields(), submit,
                  {"name": row["Пән"], "credits": row["Кредит"]})

    def delete(self):
        row = self.pick(self.table)
        if row and confirm(f"{row['Пән']} пәнін жою керек пе? Бағалары да жойылады."):
            self.db.execute("DELETE FROM dbo.subjects WHERE id = ?", (row["id"],))
            self.reload()


class UsersPage(Page):
    title = "Пайдаланушылар"

    def build(self):
        bar = self.bar()
        self.table = DataTable(self)
        self.search_box(bar, self.table)
        self.btn(bar, "Оқытушы/әкімші", self.add, width=160)
        self.btn(bar, "Пароль", self.reset)
        self.btn(bar, "Жою", self.delete)
        export_buttons(bar, self.table, "Пайдаланушылар")
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        cols, rows = self.db.query(
            "SELECT id, username AS [Логин], full_name AS [Аты-жөні], user_role AS [Рөлі]"
            " FROM dbo.users ORDER BY user_role, full_name")
        self.table.load(cols, rows, hidden=("id",))

    def add(self):
        def submit(v):
            if len(v["username"]) < 3 or not v["full_name"]:
                return "Логин (кемінде 3 таңба) мен аты-жөнін толтырыңыз."
            if len(v["password"]) < config.MIN_PASSWORD_LEN:
                return f"Пароль кемінде {config.MIN_PASSWORD_LEN} таңба болсын."
            self.db.call("sp_RegisterUser", v["username"], hash_password(v["password"]),
                         v["full_name"], v["role"], None, None)
            self.reload()
        self.form("Жаңа пайдаланушы", [
            {"name": "username", "label": "Логин"},
            {"name": "password", "label": "Пароль", "kind": "password"},
            {"name": "full_name", "label": "Аты-жөні"},
            {"name": "role", "label": "Рөлі", "kind": "combo",
             "options": [("TEACHER", "Оқытушы"), ("ADMIN", "Әкімші")]},
        ], submit)

    def reset(self):
        row = self.pick(self.table)
        if not row:
            return

        def submit(v):
            if len(v["password"]) < config.MIN_PASSWORD_LEN:
                return f"Пароль кемінде {config.MIN_PASSWORD_LEN} таңба болсын."
            self.db.call("sp_ChangePassword", row["id"], hash_password(v["password"]))
        self.form(f"Жаңа пароль: {row['Логин']}",
                  [{"name": "password", "label": "Жаңа пароль", "kind": "password"}], submit)

    def delete(self):
        row = self.pick(self.table)
        if not row:
            return
        if row["id"] == self.user["id"]:
            return show_info("Өз аккаунтыңызды жоя алмайсыз.")
        if row["Рөлі"] == "STUDENT":
            return show_info("Студентті «Студенттер» бетінен жойыңыз.")
        if confirm(f"{row['Логин']} аккаунтын жою керек пе?"):
            self.db.execute("DELETE FROM dbo.users WHERE id = ?", (row["id"],))
            self.reload()


class AssignmentsPage(Page):
    title = "Оқытушы жүктемесі"

    def build(self):
        bar = self.bar()
        self.table = DataTable(self)
        self.search_box(bar, self.table)
        self.btn(bar, "Тағайындау", self.add, width=130)
        self.btn(bar, "Жою", self.delete)
        export_buttons(bar, self.table, "Жүктеме")
        ctk.CTkLabel(self, anchor="w", text="Оқытушы тек өзіне тағайындалған пән мен топқа "
                     "баға қоя алады.").pack(fill="x")
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        cols, rows = self.db.query(
            "SELECT ta.id, u.full_name AS [Оқытушы], sub.subject_name AS [Пән],"
            " g.group_name AS [Топ] FROM dbo.teaching_assignments ta"
            " JOIN dbo.users u ON u.id = ta.teacher_id"
            " JOIN dbo.subjects sub ON sub.id = ta.subject_id"
            " JOIN dbo.study_groups g ON g.id = ta.group_id"
            " ORDER BY u.full_name, sub.subject_name, g.group_name")
        self.table.load(cols, rows, hidden=("id",))

    def add(self):
        teachers = [(r[0], r[1]) for r in self.db.rows(
            "SELECT id, full_name + N' (' + username + N')' FROM dbo.users"
            " WHERE user_role = N'TEACHER' ORDER BY full_name")]
        subjects, groups = self.subjects(), self.groups()
        if not (teachers and subjects and groups):
            return show_info("Тағайындау үшін оқытушы, пән және топ керек.")

        def submit(v):
            self.db.execute(
                "INSERT INTO dbo.teaching_assignments (teacher_id, subject_id, group_id)"
                " VALUES (?, ?, ?)", (v["teacher"], v["subject"], v["group"]))
            self.reload()
        self.form("Жүктеме тағайындау", [
            {"name": "teacher", "label": "Оқытушы", "kind": "combo", "options": teachers},
            {"name": "subject", "label": "Пән", "kind": "combo", "options": subjects},
            {"name": "group", "label": "Топ", "kind": "combo", "options": groups},
        ], submit)

    def delete(self):
        row = self.pick(self.table)
        if row and confirm("Жүктемені жою керек пе?"):
            self.db.execute("DELETE FROM dbo.teaching_assignments WHERE id = ?", (row["id"],))
            self.reload()


class TimetablePage(Page):
    title = "Сабақ кестесі"

    def build(self):
        bar = self.bar()
        self.table = DataTable(self)
        self.search_box(bar, self.table)
        self.admin = self.role == "ADMIN"
        if self.admin:
            self.btn(bar, "Қосу", self.add)
            self.btn(bar, "Жою", self.delete)
        export_buttons(bar, self.table, "Сабақ кестесі")
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        sql = ("SELECT t.id, t.group_id, g.group_name AS [Топ], s.subject_name AS [Пән],"
               " t.day_of_week AS [Күні], t.time_slot AS [Уақыты], t.room AS [Аудитория]"
               " FROM dbo.timetable t JOIN dbo.subjects s ON s.id = t.subject_id"
               " JOIN dbo.study_groups g ON g.id = t.group_id")
        params = ()
        if self.role == "STUDENT":
            sql += " WHERE t.group_id = ?"
            params = (self.app.student["group_id"],)
        cols, rows = self.db.query(sql + " ORDER BY g.group_name, t.id", params)
        self.table.load(cols, rows, hidden=("id", "group_id"))

    def add(self):
        groups, subjects = self.groups(), self.subjects()
        if not (groups and subjects):
            return show_info("Алдымен топ пен пән қосыңыз.")

        def submit(v):
            if not v["slot"]:
                return "Уақытын жазыңыз (мысалы, 09:00 - 10:20)."
            self.db.execute(
                "INSERT INTO dbo.timetable (group_id, subject_id, day_of_week, time_slot, room)"
                " VALUES (?, ?, ?, ?, ?)",
                (v["group"], v["subject"], v["day"], v["slot"], v["room"]))
            self.reload()
        self.form("Кестеге сабақ қосу", [
            {"name": "group", "label": "Топ", "kind": "combo", "options": groups},
            {"name": "subject", "label": "Пән", "kind": "combo", "options": subjects},
            {"name": "day", "label": "Апта күні", "kind": "combo",
             "options": [(d, d) for d in config.DAYS]},
            {"name": "slot", "label": "Уақыты (09:00 - 10:20)"},
            {"name": "room", "label": "Аудитория"},
        ], submit)

    def delete(self):
        row = self.pick(self.table)
        if row and confirm("Жазбаны жою керек пе?"):
            self.db.execute("DELETE FROM dbo.timetable WHERE id = ?", (row["id"],))
            self.reload()


class AnnouncementsPage(Page):
    title = "Хабарландырулар"

    def build(self):
        bar = self.bar()
        self.table = DataTable(self)
        self.btn(bar, "Оқу", self.read)
        if self.role == "ADMIN":
            self.btn(bar, "Жариялау", self.add)
            self.btn(bar, "Жою", self.delete)
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        sql = ("SELECT a.id, a.title AS [Тақырып],"
               " ISNULL(g.group_name, N'Барлығы') AS [Кімге], a.created_at AS [Уақыты],"
               " a.content AS [Мәтін]"
               " FROM dbo.announcements a LEFT JOIN dbo.study_groups g ON g.id = a.target_group_id")
        params = ()
        if self.role == "STUDENT":
            sql += " WHERE a.target_group_id IS NULL OR a.target_group_id = ?"
            params = (self.app.student["group_id"],)
        cols, rows = self.db.query(sql + " ORDER BY a.created_at DESC", params)
        self.table.load(cols, rows, hidden=("id", "Мәтін"))

    def read(self):
        row = self.pick(self.table)
        if row:
            messagebox.showinfo(row["Тақырып"], row["Мәтін"])

    def add(self):
        def submit(v):
            if not v["title"] or not v["content"]:
                return "Тақырып пен мәтінді толтырыңыз."
            self.db.execute(
                "INSERT INTO dbo.announcements (title, content, target_group_id) VALUES (?, ?, ?)",
                (v["title"], v["content"], v["target"]))
            self.reload()
        self.form("Хабарландыру", [
            {"name": "title", "label": "Тақырыбы"},
            {"name": "content", "label": "Мәтіні", "kind": "text"},
            {"name": "target", "label": "Кімге", "kind": "combo",
             "options": [(None, "Барлығы")] + self.groups()},
        ], submit)

    def delete(self):
        row = self.pick(self.table)
        if row and confirm("Хабарландыруды жою керек пе?"):
            self.db.execute("DELETE FROM dbo.announcements WHERE id = ?", (row["id"],))
            self.reload()


class AuditPage(Page):
    title = "Аудит логтары"

    def build(self):
        bar = self.bar()
        self.table = DataTable(self)
        self.search_box(bar, self.table)
        self.btn(bar, "Жаңарту", self.reload)
        export_buttons(bar, self.table, "Аудит")
        ctk.CTkLabel(self, anchor="w", text="Бағалар мен студенттердің өзгерісін SQL Server "
                     "триггерлері автоматты түрде жазады.").pack(fill="x")
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        cols, rows = self.db.query(
            "SELECT TOP 1000 id, username AS [Пайдаланушы], action AS [Әрекет],"
            " created_at AS [Уақыты] FROM dbo.audit_logs ORDER BY id DESC")
        self.table.load(cols, rows, hidden=("id",))


class BackupPage(Page):
    title = "Резервтік көшірме"

    def build(self):
        ctk.CTkLabel(self, anchor="w", justify="left", wraplength=700, text=(
            "«Көшірме жасау» батырмасы SQL Server-дің BACKUP DATABASE командасын "
            "сақталатын процедура арқылы іске қосады. Файл (.bak) сервердің әдепкі "
            "backup қалтасында сақталады.\n\nҚалпына келтіру: SSMS-те "
            "sql/restore.sql файлын ашып, файл жолын көрсетіп іске қосыңыз.")
        ).pack(fill="x", pady=8)
        self.btn(self, "Көшірме жасау", self.make, width=180)
        self.out = ctk.CTkLabel(self, text="", anchor="w", justify="left", wraplength=700)
        self.out.pack(fill="x", pady=10)

    def make(self):
        path = self.db.backup()
        self.out.configure(text=f"Көшірме жасалды:\n{path}")


# ======================= ОҚЫТУШЫ =======================
class JournalPage(Page):
    title = "Электрондық журнал"

    def build(self):
        self.pairs = self.db.rows(
            "SELECT ta.subject_id, sub.subject_name, ta.group_id, g.group_name"
            " FROM dbo.teaching_assignments ta"
            " JOIN dbo.subjects sub ON sub.id = ta.subject_id"
            " JOIN dbo.study_groups g ON g.id = ta.group_id"
            " WHERE ta.teacher_id = ? ORDER BY sub.subject_name, g.group_name",
            (self.user["id"],))
        self.table = DataTable(self)
        if not self.pairs:
            ctk.CTkLabel(self, wraplength=600, justify="left", text=(
                "Сізге әлі пән мен топ тағайындалмаған. Әкімшіге хабарласыңыз "
                "(«Оқытушы жүктемесі» бөлімі).")).pack(anchor="w")
            return
        self.labels = [f"{p[1]} — {p[3]}" for p in self.pairs]
        bar = self.bar()
        self.combo = ctk.CTkComboBox(bar, values=self.labels, width=380, state="readonly",
                                     command=lambda _v: self.reload())
        self.combo.set(self.labels[0])
        self.combo.pack(side="left", padx=4)
        self.search_box(bar, self.table)
        bar2 = self.bar()
        self.btn(bar2, "Баға қою", self.add)
        self.btn(bar2, "Өзгерту", self.edit)
        self.btn(bar2, "Жою", self.delete)
        export_buttons(bar2, self.table, "Журнал")
        self.table.pack(fill="both", expand=True)

    def current(self):
        return self.pairs[self.labels.index(self.combo.get())]

    def refresh(self):
        if not self.pairs:
            return
        sub_id, _, grp_id, _ = self.current()
        cols, rows = self.db.query(
            "SELECT grade_id, student_id, full_name AS [Студент], lesson_date AS [Күні],"
            " grade AS [Баға], attendance AS [Қатысуы] FROM dbo.v_journal"
            " WHERE subject_id = ? AND group_id = ? ORDER BY lesson_date DESC, full_name",
            (sub_id, grp_id))
        self.table.load(cols, rows, hidden=("grade_id", "student_id"))

    def _dialog(self, title, initial=None, lock_student=False):
        sub_id, _, grp_id, _ = self.current()
        studs = [(r[0], r[1]) for r in self.db.rows(
            "SELECT id, full_name FROM dbo.students WHERE group_id = ? ORDER BY full_name",
            (grp_id,))]
        if not studs:
            return show_info("Бұл топта студент жоқ.")
        if lock_student and initial:
            studs = [s for s in studs if s[0] == initial["student"]]

        def submit(v):
            d = parse_date(v["date"])
            if d is None:
                return "Күнін ЖЖЖЖ-АА-КК форматында жазыңыз (2026-10-31)."
            if not v["grade"].isdigit() or not 0 <= int(v["grade"]) <= 100:
                return "Баға 0-100 аралығындағы сан болсын."
            res = self.db.call("sp_SetGrade", v["student"], sub_id, int(v["grade"]),
                               v["att"], d.isoformat(), self.user["id"])
            self.reload()
            if res and res[0][0]:
                show_info("Сол күнгі баға жаңартылды.")
        self.form(title, [
            {"name": "student", "label": "Студент", "kind": "combo", "options": studs},
            {"name": "grade", "label": "Баға (0-100)"},
            {"name": "att", "label": "Қатысуы", "kind": "combo",
             "options": [(a, a) for a in config.ATTENDANCE]},
            {"name": "date", "label": "Күні (ЖЖЖЖ-АА-КК)"},
        ], submit, initial or {"date": str(datetime.date.today()), "grade": "80"})

    def add(self):
        self._dialog("Баға қою")

    def edit(self):
        row = self.pick(self.table)
        if row:
            self._dialog("Бағаны өзгерту", {
                "student": row["student_id"], "grade": row["Баға"] if row["Баға"] is not None else "",
                "att": row["Қатысуы"], "date": str(row["Күні"])}, lock_student=True)

    def delete(self):
        row = self.pick(self.table)
        if row and confirm("Бағаны жою керек пе?"):
            self.db.call("sp_DeleteGrade", row["grade_id"], self.user["id"])
            self.reload()


class TeacherHomeworkPage(Page):
    title = "Үй тапсырмалары"

    def build(self):
        self.pairs = self.db.rows(
            "SELECT ta.subject_id, sub.subject_name, ta.group_id, g.group_name"
            " FROM dbo.teaching_assignments ta"
            " JOIN dbo.subjects sub ON sub.id = ta.subject_id"
            " JOIN dbo.study_groups g ON g.id = ta.group_id"
            " WHERE ta.teacher_id = ? ORDER BY sub.subject_name, g.group_name",
            (self.user["id"],))
        bar = self.bar()
        self.table = DataTable(self, height=8)
        self.subs = DataTable(self, height=7)
        self.btn(bar, "Тапсырма беру", self.add, width=150)
        self.btn(bar, "Жою", self.delete)
        export_buttons(bar, self.table, "Тапсырмалар")
        self.table.pack(fill="both", expand=True)
        ctk.CTkLabel(self, text="Тапсырылған жұмыстар (тапсырманы таңдаңыз):",
                     anchor="w").pack(fill="x", pady=(8, 0))
        self.subs.pack(fill="both", expand=True)
        self.table.tree.bind("<<TreeviewSelect>>", lambda _e: self.show_subs())

    def refresh(self):
        cols, rows = self.db.query(
            "SELECT h.id, h.group_id, sub.subject_name AS [Пән], g.group_name AS [Топ],"
            " h.title AS [Тақырып], h.deadline AS [Мерзімі],"
            " (SELECT COUNT(*) FROM dbo.submissions sb WHERE sb.homework_id = h.id) AS [Тапсырған],"
            " (SELECT COUNT(*) FROM dbo.students st WHERE st.group_id = h.group_id) AS [Студент]"
            " FROM dbo.homeworks h JOIN dbo.subjects sub ON sub.id = h.subject_id"
            " JOIN dbo.study_groups g ON g.id = h.group_id"
            " WHERE EXISTS (SELECT 1 FROM dbo.teaching_assignments ta WHERE ta.teacher_id = ?"
            " AND ta.subject_id = h.subject_id AND ta.group_id = h.group_id)"
            " ORDER BY h.id DESC", (self.user["id"],))
        self.table.load(cols, rows, hidden=("id", "group_id"))
        self.subs.load(["Код", "Студент", "Уақыты", "Жауап"], [])

    @safe
    def show_subs(self):
        row = self.table.selected()
        if not row:
            return
        cols, rows = self.db.query(
            "SELECT st.student_code AS [Код], st.full_name AS [Студент],"
            " sb.submitted_at AS [Уақыты], sb.content AS [Жауап]"
            " FROM dbo.submissions sb JOIN dbo.students st ON st.id = sb.student_id"
            " WHERE sb.homework_id = ? ORDER BY sb.submitted_at", (row["id"],))
        self.subs.load(cols, rows)

    def add(self):
        if not self.pairs:
            return show_info("Сізге әлі пән мен топ тағайындалмаған.")
        opts = [(i, f"{p[1]} — {p[3]}") for i, p in enumerate(self.pairs)]

        def submit(v):
            d = parse_date(v["deadline"])
            if not v["title"] or d is None:
                return "Тақырыпты және мерзімді (ЖЖЖЖ-АА-КК) толтырыңыз."
            p = self.pairs[v["pair"]]
            self.db.execute(
                "INSERT INTO dbo.homeworks (subject_id, group_id, title, description, deadline)"
                " VALUES (?, ?, ?, ?, ?)", (p[0], p[2], v["title"], v["desc"], d.isoformat()))
            self.reload()
        self.form("Жаңа тапсырма", [
            {"name": "pair", "label": "Пән / топ", "kind": "combo", "options": opts},
            {"name": "title", "label": "Тақырыбы"},
            {"name": "desc", "label": "Сипаттамасы", "kind": "text"},
            {"name": "deadline", "label": "Мерзімі (ЖЖЖЖ-АА-КК)"},
        ], submit, {"deadline": str(datetime.date.today() + datetime.timedelta(days=7))})

    def delete(self):
        row = self.pick(self.table)
        if row and confirm("Тапсырманы және тапсырылған жұмыстарды жою керек пе?"):
            self.db.execute("DELETE FROM dbo.homeworks WHERE id = ?", (row["id"],))
            self.reload()


# ======================= СТУДЕНТ =======================
class StudentJournalPage(Page):
    title = "Журнал және GPA"

    def build(self):
        self.info = ctk.CTkLabel(self, anchor="w", font=ctk.CTkFont(size=16))
        self.info.pack(fill="x", pady=(0, 8))
        bar = self.bar()
        self.table = DataTable(self)
        self.search_box(bar, self.table)
        export_buttons(bar, self.table, "Менің бағаларым")
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        sid = self.app.student["id"]
        cols, rows = self.db.query(
            "SELECT subject_name AS [Пән], lesson_date AS [Күні], grade AS [Баға],"
            " attendance AS [Қатысуы], credits AS [Кредит] FROM dbo.v_journal"
            " WHERE student_id = ? ORDER BY lesson_date DESC", (sid,))
        self.table.load(cols, rows)
        gpa = self.db.rows("SELECT gpa FROM dbo.v_student_gpa WHERE student_id = ?", (sid,))
        st = self.db.rows("SELECT avg_grade, attendance_pct FROM dbo.v_student_stats"
                          " WHERE student_id = ?", (sid,))
        g = gpa[0][0] if gpa else 0
        avg = st[0][0] if st and st[0][0] is not None else 0
        att = st[0][1] if st and st[0][1] is not None else 0
        self.info.configure(text=f"GPA: {g}    Орташа баға: {avg}    Қатысу: {att}%")


class StudentHomeworkPage(Page):
    title = "Үй тапсырмалары"

    def build(self):
        bar = self.bar()
        self.table = DataTable(self)
        self.btn(bar, "Сипаттама", self.read)
        self.btn(bar, "Тапсыру", self.submit, width=120)
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        sid, gid = self.app.student["id"], self.app.student["group_id"]
        cols, rows = self.db.query(
            "SELECT h.id, sub.subject_name AS [Пән], h.title AS [Тақырып],"
            " h.deadline AS [Мерзімі],"
            " CASE WHEN EXISTS (SELECT 1 FROM dbo.submissions sb WHERE sb.homework_id = h.id"
            " AND sb.student_id = ?) THEN N'Тапсырылды' ELSE N'Тапсырылмады' END AS [Күйі],"
            " h.description"
            " FROM dbo.homeworks h JOIN dbo.subjects sub ON sub.id = h.subject_id"
            " WHERE h.group_id = ? ORDER BY h.deadline", (sid, gid))
        self.table.load(cols, rows, hidden=("id", "description"))

    def read(self):
        row = self.pick(self.table)
        if row:
            messagebox.showinfo(row["Тақырып"], row["description"] or "Сипаттама жоқ.")

    def submit(self):
        row = self.pick(self.table)
        if not row:
            return

        def on_submit(v):
            if not v["content"]:
                return "Жауабыңызды жазыңыз."
            self.db.call("sp_SubmitHomework", row["id"], self.app.student["id"], v["content"])
            self.reload()
        self.form(f"Тапсыру: {row['Тақырып']}",
                  [{"name": "content", "label": "Жауабыңыз", "kind": "text"}], on_submit)


# ======================= ЕСЕПТЕР =======================
class ReportsPage(Page):
    title = "SQL есептер"

    def build(self):
        bar = self.bar()
        self.titles = [r["title"] for r in REPORTS]
        self.combo = ctk.CTkComboBox(bar, values=self.titles, width=420, state="readonly",
                                     command=lambda _v: self.reload())
        self.combo.set(self.titles[0])
        self.combo.pack(side="left", padx=4)
        self.table = DataTable(self, height=10)
        export_buttons(bar, self.table, "SQL есеп")
        self.concept = ctk.CTkLabel(self, anchor="w")
        self.concept.pack(fill="x")
        self.code = ctk.CTkTextbox(self, height=170, font=ctk.CTkFont(family="Consolas", size=12))
        self.code.pack(fill="x", pady=6)
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        r = REPORTS[self.titles.index(self.combo.get())]
        self.concept.configure(text=f"Қолданылған SQL құралдары: {r['concept']}")
        self.code.configure(state="normal")
        self.code.delete("1.0", "end")
        self.code.insert("1.0", r["sql"])
        self.code.configure(state="disabled")
        cols, rows = self.db.query(r["sql"])
        self.table.load(cols, rows)


class ChartsPage(Page):
    title = "Диаграммалар"

    def build(self):
        self.holder = ctk.CTkFrame(self, fg_color="transparent")
        self.holder.pack(fill="both", expand=True)

    def refresh(self):
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
        from matplotlib.figure import Figure

        for w in self.holder.winfo_children():
            w.destroy()
        q = self.db.rows
        by_subject = q("SELECT subject_name, CAST(AVG(CAST(grade AS DECIMAL(5,2))) AS FLOAT)"
                       " FROM dbo.v_journal WHERE grade IS NOT NULL GROUP BY subject_name")
        by_group = q("SELECT group_name, CAST(AVG(CAST(grade AS DECIMAL(5,2))) AS FLOAT)"
                     " FROM dbo.v_journal WHERE grade IS NOT NULL GROUP BY group_name")
        att = q("SELECT attendance, COUNT(*) FROM dbo.v_journal GROUP BY attendance")
        grades = [r[0] for r in q("SELECT grade FROM dbo.v_journal WHERE grade IS NOT NULL")]
        if not grades:
            ctk.CTkLabel(self.holder, text="Диаграмма үшін деректер жоқ.").pack(pady=20)
            return
        fig = Figure(figsize=(10, 6), dpi=100)
        a1, a2 = fig.add_subplot(221), fig.add_subplot(222)
        a3, a4 = fig.add_subplot(223), fig.add_subplot(224)
        names = [(n if len(n) < 22 else n[:20] + "…") for n, _ in by_subject]
        a1.barh(names, [float(v) for _, v in by_subject], color="#1F6AA5")
        a1.set_title("Пәндер бойынша орташа баға")
        a1.set_xlim(0, 100)
        a2.bar([n for n, _ in by_group], [float(v) for _, v in by_group], color="#2E8B57")
        a2.set_title("Топтар бойынша орташа баға")
        a2.set_ylim(0, 100)
        a3.hist(grades, bins=range(0, 110, 10), color="#E08E0B", edgecolor="white")
        a3.set_title("Бағалар таралуы")
        a4.pie([c for _, c in att], labels=[a for a, _ in att], autopct="%1.0f%%")
        a4.set_title("Қатысу үлесі")
        fig.tight_layout()
        canvas = FigureCanvasTkAgg(fig, master=self.holder)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)
