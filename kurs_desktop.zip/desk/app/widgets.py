"""Қайта қолданылатын виджеттер: кесте (іздеу/сұрыптау), форма, экспорт батырмалары."""
import datetime
import decimal
from tkinter import filedialog, messagebox, ttk

import customtkinter as ctk

from app import export
from app.db import friendly
from app.theme import (BG, BORDER, CARD, FONT, PRIMARY, PRIMARY_HOVER, SECONDARY,
                       SECONDARY_HOVER, TEXT, ZEBRA)


def fmt(v) -> str:
    if v is None:
        return ""
    if isinstance(v, decimal.Decimal):
        return f"{v:f}".rstrip("0").rstrip(".") if v % 1 else str(int(v))
    if isinstance(v, datetime.datetime):
        return v.strftime("%Y-%m-%d %H:%M")
    return str(v)


def _sort_key(v):
    if v is None:
        return (1, 0.0, "")
    if isinstance(v, (int, float, decimal.Decimal)):
        return (0, float(v), "")
    return (0, 0.0, str(v).lower())


def show_error(e):
    messagebox.showerror("Қате", friendly(e) if isinstance(e, Exception) else str(e))


def show_info(msg):
    messagebox.showinfo("Хабарлама", msg)


def confirm(msg) -> bool:
    return messagebox.askyesno("Растау", msg)


class DataTable(ctk.CTkFrame):
    """Тақырыпты басқанда сұрыптайды; іздеу мен баған бойынша сүзгі бар.

    Бағандардың аты - SQL алиасы. `hidden` ішіндегі бағандар көрсетілмейді,
    бірақ selected() қайтаратын сөздікте бар (мысалы, id).
    """

    def __init__(self, master, height=14):
        super().__init__(master, fg_color=CARD, corner_radius=12, border_width=1,
                         border_color=BORDER)
        self.cols, self.rows, self.hidden = [], [], set()
        self._view = []
        self._sort_col, self._sort_rev = None, False
        self._text, self._eq = "", None
        self.tree = ttk.Treeview(self, show="headings", selectmode="browse", height=height)
        vs = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        hs = ttk.Scrollbar(self, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        self.tree.tag_configure("odd", background=ZEBRA)
        self.tree.grid(row=0, column=0, sticky="nsew", padx=(8, 0), pady=(8, 0))
        vs.grid(row=0, column=1, sticky="ns", pady=(8, 0), padx=(0, 4))
        hs.grid(row=1, column=0, sticky="ew", padx=(8, 0), pady=(0, 4))
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

    @property
    def shown(self):
        return [c for c in self.cols if c not in self.hidden]

    def load(self, cols, rows, hidden=()):
        self.cols, self.rows, self.hidden = list(cols), list(rows), set(hidden)
        ids = [f"c{i}" for i in range(len(self.shown))]  # бос орынсыз ішкі атаулар
        self.tree.configure(columns=ids)
        for cid, c in zip(ids, self.shown):
            self.tree.heading(cid, text=c, command=lambda col=c: self.sort_by(col))
            self.tree.column(cid, width=max(90, min(260, len(c) * 11 + 30)), anchor="w")
        self._render()

    def sort_by(self, col):
        self._sort_rev = (not self._sort_rev) if self._sort_col == col else False
        self._sort_col = col
        self._render()

    def apply(self, text="", eq=None):
        """text - барлық бағаннан іздеу; eq=(баған, мән) - нақты сәйкестік."""
        self._text, self._eq = text.strip().lower(), eq
        self._render()

    def _render(self):
        rows = self.rows
        if self._eq and self._eq[0] in self.cols:
            i = self.cols.index(self._eq[0])
            rows = [r for r in rows if r[i] == self._eq[1]]
        if self._text:
            idx = [self.cols.index(c) for c in self.shown]
            rows = [r for r in rows
                    if any(self._text in fmt(r[i]).lower() for i in idx)]
        if self._sort_col in self.cols:
            i = self.cols.index(self._sort_col)
            rows = sorted(rows, key=lambda r: _sort_key(r[i]), reverse=self._sort_rev)
        self._view = list(rows)
        self.tree.delete(*self.tree.get_children())
        idx = [self.cols.index(c) for c in self.shown]
        for n, r in enumerate(self._view):
            self.tree.insert("", "end", iid=str(n), values=[fmt(r[i]) for i in idx],
                             tags=("odd",) if n % 2 else ())

    def selected(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return dict(zip(self.cols, self._view[int(sel[0])]))

    def visible_data(self):
        idx = [self.cols.index(c) for c in self.shown]
        return self.shown, [[r[i] for i in idx] for r in self._view]


class FormDialog(ctk.CTkToplevel):
    """fields: [{name,label,kind:'entry'|'password'|'combo'|'text', options:[(value,label)]}]

    on_submit(values) -> None (сәтті) немесе қате мәтіні (диалог ашық қалады).
    """

    def __init__(self, master, title, fields, on_submit, initial=None, submit_text="Сақтау"):
        super().__init__(master, fg_color=BG)
        self.title(title)
        self.on_submit = on_submit
        self.fields = fields
        self.widgets, self.maps = {}, {}
        initial = initial or {}
        self.geometry("460x" + str(min(120 + 74 * len(fields) + (60 if any(
            f.get("kind") == "text" for f in fields) else 0), 720)))
        self.resizable(False, False)
        body = ctk.CTkScrollableFrame(self, fg_color=CARD, corner_radius=12)
        body.pack(fill="both", expand=True, padx=12, pady=(12, 0))
        for f in fields:
            ctk.CTkLabel(body, text=f["label"], anchor="w", text_color=TEXT,
                         font=ctk.CTkFont(family=FONT, size=13)).pack(fill="x", pady=(8, 2))
            kind = f.get("kind", "entry")
            if kind == "combo":
                opts = f.get("options", [])
                labels = [lbl for _, lbl in opts]
                self.maps[f["name"]] = {lbl: val for val, lbl in opts}
                w = ctk.CTkComboBox(body, values=labels or [""], state="readonly",
                                    height=36, corner_radius=8)
                start = labels[0] if labels else ""
                if f["name"] in initial:
                    for val, lbl in opts:
                        if val == initial[f["name"]]:
                            start = lbl
                w.set(start)
            elif kind == "text":
                w = ctk.CTkTextbox(body, height=90)
                w.insert("1.0", str(initial.get(f["name"], "") or ""))
            else:
                w = ctk.CTkEntry(body, show="*" if kind == "password" else "",
                                 height=36, corner_radius=8, border_color=BORDER)
                if initial.get(f["name"]) is not None:
                    w.insert(0, str(initial[f["name"]]))
            w.pack(fill="x")
            self.widgets[f["name"]] = (kind, w)
        self.err = ctk.CTkLabel(self, text="", text_color="#C0392B", wraplength=420)
        self.err.pack(pady=(6, 0))
        ctk.CTkButton(self, text=submit_text, command=self._submit, height=38, width=200,
                      corner_radius=8, fg_color=PRIMARY, hover_color=PRIMARY_HOVER,
                      font=ctk.CTkFont(family=FONT, size=14, weight="bold")).pack(pady=12)
        self.bind("<Return>", lambda e: self._submit() if not any(
            k == "text" for k, _ in self.widgets.values()) else None)
        self.after(150, self._focus)

    def _focus(self):
        try:
            self.lift()
            self.focus_force()
            self.grab_set()
        except Exception:
            pass

    def values(self) -> dict:
        out = {}
        for name, (kind, w) in self.widgets.items():
            if kind == "combo":
                out[name] = self.maps[name].get(w.get())
            elif kind == "text":
                out[name] = w.get("1.0", "end").strip()
            else:
                out[name] = w.get().strip()
        return out

    def _submit(self):
        try:
            err = self.on_submit(self.values())
        except Exception as e:  # SQL қатесі
            err = friendly(e)
        if err:
            self.err.configure(text=err)
        else:
            self.grab_release()
            self.destroy()


def export_buttons(parent, table: DataTable, title: str):
    """Кестенің қазіргі көрінісін Excel / PDF-ке экспорттайтын батырмалар."""

    def run(kind):
        headers, rows = table.visible_data()
        if not rows:
            show_info("Экспорттайтын деректер жоқ.")
            return
        ext = ".xlsx" if kind == "xlsx" else ".pdf"
        path = filedialog.asksaveasfilename(
            defaultextension=ext, initialfile=f"{title}{ext}",
            filetypes=[("Excel" if kind == "xlsx" else "PDF", f"*{ext}")])
        if not path:
            return
        try:
            (export.export_excel if kind == "xlsx" else export.export_pdf)(
                path, title, headers, rows)
            show_info(f"Сақталды:\n{path}")
        except Exception as e:
            show_error(e)

    for label, kind in (("Excel", "xlsx"), ("PDF", "pdf")):
        ctk.CTkButton(parent, text=label, width=70, height=34, corner_radius=8,
                      fg_color=SECONDARY, hover_color=SECONDARY_HOVER, text_color=TEXT,
                      font=ctk.CTkFont(family=FONT, size=13),
                      command=lambda k=kind: run(k)).pack(side="left", padx=4)
