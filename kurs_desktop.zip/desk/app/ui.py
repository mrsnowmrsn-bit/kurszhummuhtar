"""Басты терезе: кіру/тіркелу, рөл бойынша мәзір, пароль ауыстыру."""
import tkinter as tk
from tkinter import messagebox, ttk

import customtkinter as ctk

from app import config, pages
from app.db import Database, friendly
from app.security import hash_password, verify_password
from app.theme import (BG, BORDER, CARD, DANGER, DANGER_HOVER, FONT, MUTED, PRIMARY,
                       PRIMARY_HOVER, SIDEBAR, SIDEBAR_HOVER, SIDEBAR_TEXT, TEXT)
from app.widgets import FormDialog, show_error, show_info

MENUS = {
    "ADMIN": [
        ("Басты бет", pages.DashboardPage),
        ("Студенттер", pages.StudentsPage),
        ("Топтар", pages.GroupsPage),
        ("Пәндер", pages.SubjectsPage),
        ("Пайдаланушылар", pages.UsersPage),
        ("Жүктеме", pages.AssignmentsPage),
        ("Кесте", pages.TimetablePage),
        ("Хабарландыру", pages.AnnouncementsPage),
        ("SQL есептер", pages.ReportsPage),
        ("Диаграммалар", pages.ChartsPage),
        ("Аудит", pages.AuditPage),
        ("Көшірме", pages.BackupPage),
    ],
    "TEACHER": [
        ("Журнал", pages.JournalPage),
        ("Тапсырмалар", pages.TeacherHomeworkPage),
        ("Кесте", pages.TimetablePage),
        ("SQL есептер", pages.ReportsPage),
        ("Диаграммалар", pages.ChartsPage),
    ],
    "STUDENT": [
        ("Журнал / GPA", pages.StudentJournalPage),
        ("Кесте", pages.TimetablePage),
        ("Тапсырмалар", pages.StudentHomeworkPage),
        ("Хабарландыру", pages.AnnouncementsPage),
    ],
}


class LoginFrame(ctk.CTkFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color=BG)
        self.app = app
        left = ctk.CTkFrame(self, fg_color=PRIMARY, corner_radius=0, width=460)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
        ctk.CTkLabel(left, text="Университет\nжурналы", justify="left", anchor="w",
                     text_color="white",
                     font=ctk.CTkFont(family=FONT, size=38, weight="bold")).pack(
            fill="x", padx=48, pady=(150, 12))
        ctk.CTkLabel(left, text="Студенттер, бағалар, сабақ кестесі және\nесептер бір жерде.",
                     justify="left", anchor="w", text_color="#DBEAFE",
                     font=ctk.CTkFont(family=FONT, size=16)).pack(fill="x", padx=48)
        ctk.CTkLabel(left, text="SQL Server  •  Python", anchor="w", text_color="#BFDBFE",
                     font=ctk.CTkFont(family=FONT, size=13)).pack(
            side="bottom", fill="x", padx=48, pady=32)

        right = ctk.CTkFrame(self, fg_color="transparent")
        right.pack(side="left", fill="both", expand=True)
        card = ctk.CTkFrame(right, corner_radius=18, fg_color=CARD, border_width=1,
                            border_color=BORDER)
        card.place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkLabel(card, text="Жүйеге кіру", text_color=TEXT,
                     font=ctk.CTkFont(family=FONT, size=24, weight="bold")).pack(
            padx=40, pady=(28, 0))
        ctk.CTkLabel(card, text="Аккаунтыңызбен кіріңіз немесе тіркеліңіз",
                     text_color=MUTED, font=ctk.CTkFont(family=FONT, size=13)).pack()
        tabs = ctk.CTkTabview(card, width=380, height=420, fg_color=CARD,
                              segmented_button_selected_color=PRIMARY,
                              segmented_button_selected_hover_color=PRIMARY_HOVER)
        tabs.pack(padx=24, pady=(10, 24))
        self._login_tab(tabs.add("Кіру"))
        self._register_tab(tabs.add("Тіркелу"))

    def _entry(self, tab, placeholder, show=""):
        e = ctk.CTkEntry(tab, placeholder_text=placeholder, show=show, width=320, height=42,
                         corner_radius=10, border_color=BORDER,
                         font=ctk.CTkFont(family=FONT, size=14))
        e.pack(pady=7)
        return e

    def _button(self, tab, text, cmd):
        ctk.CTkButton(tab, text=text, width=320, height=44, corner_radius=10,
                      fg_color=PRIMARY, hover_color=PRIMARY_HOVER, command=cmd,
                      font=ctk.CTkFont(family=FONT, size=15, weight="bold")).pack(pady=10)

    # ---- кіру ----
    def _login_tab(self, tab):
        self.u = self._entry(tab, "Логин")
        self.u.pack_configure(pady=(28, 7))
        self.p = self._entry(tab, "Пароль", "*")
        self.p.bind("<Return>", lambda _e: self.login())
        self.msg = ctk.CTkLabel(tab, text="", text_color=DANGER, wraplength=320)
        self.msg.pack(pady=4)
        self._button(tab, "Кіру", self.login)

    def login(self):
        db = self.app.db
        name, pw = self.u.get().strip(), self.p.get()
        try:
            rows = db.call("sp_GetUser", name) if name else None
            if not rows:
                self.msg.configure(text="Логин немесе пароль қате.")
                return
            uid, uname, phash, full, role, locked, left = rows[0]
            if locked:
                self.msg.configure(text=f"Аккаунт уақытша бұғатталды. ~{left + 1} минуттан соң қайталаңыз.")
                return
            if not verify_password(pw, phash):
                db.call("sp_LoginFailed", uid)
                self.msg.configure(text="Логин немесе пароль қате.")
                return
            db.set_session_user(uname)
            db.call("sp_LoginOk", uid)
            default_pw = role == "ADMIN" and verify_password(config.ADMIN_PASSWORD, phash) \
                and config.ADMIN_PASSWORD == "admin123"
            self.app.start_session({"id": uid, "username": uname, "full_name": full,
                                    "role": role}, warn_default_pw=default_pw)
        except Exception as e:
            self.msg.configure(text=friendly(e))

    # ---- тіркелу ----
    def _register_tab(self, tab):
        self.ru = self._entry(tab, "Логин")
        self.rn = self._entry(tab, "Аты-жөні")
        self.rp = self._entry(tab, "Пароль (кемінде 6 таңба)", "*")
        try:
            self.gmap = {r[1]: r[0] for r in self.app.db.rows(
                "SELECT id, group_name FROM dbo.study_groups ORDER BY group_name")}
        except Exception:
            self.gmap = {}
        self.rg = ctk.CTkComboBox(tab, values=list(self.gmap) or [""], state="readonly",
                                  width=320, height=40, corner_radius=10)
        self.rg.pack(pady=6)
        self.rc = ctk.CTkComboBox(tab, values=["1", "2", "3", "4", "5"], state="readonly",
                                  width=320, height=40, corner_radius=10)
        self.rc.set("1")
        self.rc.pack(pady=6)
        self.rmsg = ctk.CTkLabel(tab, text="", wraplength=320)
        self.rmsg.pack()
        self._button(tab, "Тіркелу", self.register)

    def register(self):
        u, n, p = self.ru.get().strip(), self.rn.get().strip(), self.rp.get()
        if len(u) < 3 or not n:
            return self.rmsg.configure(text="Логин (кемінде 3 таңба) мен аты-жөнін жазыңыз.", text_color=DANGER)
        if len(p) < config.MIN_PASSWORD_LEN:
            return self.rmsg.configure(text="Пароль тым қысқа.", text_color=DANGER)
        if self.rg.get() not in self.gmap:
            return self.rmsg.configure(text="Топ жоқ. Әкімші топ қосуы керек.", text_color=DANGER)
        try:
            self.app.db.call("sp_RegisterUser", u, hash_password(p), n, "STUDENT",
                             self.gmap[self.rg.get()], int(self.rc.get()))
            self.rmsg.configure(text="Тіркелді! «Кіру» қойындысына өтіңіз.", text_color="#16A34A")
        except Exception as e:
            self.rmsg.configure(text=friendly(e), text_color=DANGER)


class App(ctk.CTk):
    def __init__(self, db: Database):
        super().__init__()
        self.db = db
        self.user, self.student = None, None
        self.title("Университет журналы")
        self.geometry("1280x760")
        self.minsize(1000, 600)
        self.configure(fg_color=BG)
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview", rowheight=32, font=(FONT, 10), background=CARD,
                        fieldbackground=CARD, foreground=TEXT, borderwidth=0)
        style.configure("Treeview.Heading", font=(FONT, 10, "bold"), background="#E2E8F0",
                        foreground=TEXT, relief="flat", padding=(8, 8))
        style.map("Treeview", background=[("selected", "#DBEAFE")],
                  foreground=[("selected", TEXT)])
        style.map("Treeview.Heading", background=[("active", "#CBD5E1")])
        self.root_frame = None
        self.show_login()

    def _swap(self, frame):
        if self.root_frame is not None:
            self.root_frame.destroy()
        self.root_frame = frame
        frame.pack(fill="both", expand=True)

    def show_login(self):
        self.user, self.student = None, None
        self._swap(LoginFrame(self, self))

    def start_session(self, user, warn_default_pw=False):
        self.user = user
        self.student = None
        if user["role"] == "STUDENT":
            rows = self.db.rows(
                "SELECT s.id, s.group_id, g.group_name FROM dbo.students s"
                " JOIN dbo.study_groups g ON g.id = s.group_id WHERE s.user_id = ?", (user["id"],))
            if not rows:
                show_info("Студент жазбасы табылмады. Әкімшіге хабарласыңыз.")
                return self.logout()
            self.student = {"id": rows[0][0], "group_id": rows[0][1], "group_name": rows[0][2]}
        self.build_main()
        if warn_default_pw:
            messagebox.showwarning("Қауіпсіздік", "Әкімшінің әдепкі паролі өзгертілмеген. "
                                   "Сол жақтағы «Парольді өзгерту» батырмасымен өзгертіңіз.")

    def build_main(self):
        frame = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        side = ctk.CTkFrame(frame, width=250, corner_radius=0, fg_color=SIDEBAR)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        ctk.CTkLabel(side, text="Журнал", text_color="white", anchor="w",
                     font=ctk.CTkFont(family=FONT, size=24, weight="bold")).pack(
            fill="x", padx=22, pady=(26, 2))
        ctk.CTkLabel(side, text=self.user["full_name"], text_color=SIDEBAR_TEXT, anchor="w",
                     wraplength=200, justify="left",
                     font=ctk.CTkFont(family=FONT, size=13)).pack(fill="x", padx=22)
        ctk.CTkLabel(side, text=config.ROLE_LABELS[self.user["role"]], text_color="#93C5FD",
                     fg_color=SIDEBAR_HOVER, corner_radius=10, height=24,
                     font=ctk.CTkFont(family=FONT, size=12)).pack(
            anchor="w", padx=22, pady=(8, 18), ipadx=10)
        self.content = ctk.CTkFrame(frame, fg_color="transparent")
        self.content.pack(side="left", fill="both", expand=True, padx=24, pady=22)
        self.page = None
        self.menu_btns = {}
        first = None
        for label, cls in MENUS[self.user["role"]]:
            b = ctk.CTkButton(side, text=label, anchor="w", height=40, corner_radius=8,
                              fg_color="transparent", text_color=SIDEBAR_TEXT,
                              hover_color=SIDEBAR_HOVER,
                              font=ctk.CTkFont(family=FONT, size=14),
                              command=lambda c=cls: self.open_page(c))
            b.pack(fill="x", padx=12, pady=2)
            self.menu_btns[cls] = b
            first = first or cls
        ctk.CTkButton(side, text="Шығу", height=40, corner_radius=8, fg_color=DANGER,
                      hover_color=DANGER_HOVER, command=self.logout,
                      font=ctk.CTkFont(family=FONT, size=14)).pack(
            side="bottom", fill="x", padx=12, pady=(6, 16))
        ctk.CTkButton(side, text="Парольді өзгерту", height=40, corner_radius=8,
                      fg_color=SIDEBAR_HOVER, hover_color="#334155", command=self.change_password,
                      font=ctk.CTkFont(family=FONT, size=14)).pack(side="bottom", fill="x", padx=12)
        self._swap(frame)
        self.open_page(first)

    def open_page(self, cls):
        if self.page is not None:
            self.page.destroy()
        for c, b in self.menu_btns.items():
            active = c is cls
            b.configure(fg_color=PRIMARY if active else "transparent",
                        text_color="white" if active else SIDEBAR_TEXT,
                        hover_color=PRIMARY_HOVER if active else SIDEBAR_HOVER)
        try:
            self.page = cls(self.content, self)
            self.page.pack(fill="both", expand=True)
        except Exception as e:
            show_error(e)

    def logout(self):
        try:
            self.db.set_session_user(None)
        except Exception:
            pass
        self.show_login()

    def change_password(self):
        def submit(v):
            row = self.db.call("sp_GetUser", self.user["username"])[0]
            if not verify_password(v["old"], row[2]):
                return "Ескі пароль дұрыс емес."
            if len(v["new"]) < config.MIN_PASSWORD_LEN:
                return f"Жаңа пароль кемінде {config.MIN_PASSWORD_LEN} таңба болсын."
            if v["new"] != v["new2"]:
                return "Жаңа парольдер сәйкес емес."
            self.db.call("sp_ChangePassword", self.user["id"], hash_password(v["new"]))
            show_info("Пароль өзгертілді.")
        FormDialog(self, "Парольді өзгерту", [
            {"name": "old", "label": "Ескі пароль", "kind": "password"},
            {"name": "new", "label": "Жаңа пароль", "kind": "password"},
            {"name": "new2", "label": "Жаңа пароль (қайта)", "kind": "password"},
        ], submit)


def run():
    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")
    db = Database()
    try:
        db.ensure_ready()
    except Exception as e:
        r = tk.Tk()
        r.withdraw()
        messagebox.showerror(
            "SQL Server-ге қосылу мүмкін болмады",
            f"{friendly(e)}\n\nТексеріңіз:\n"
            "1) SQL Server Express орнатылған және қосулы ма;\n"
            f"2) сервер аты дұрыс па (қазір: {config.SERVER}). "
            "Басқа болса, config.ini файлына жазыңыз.")
        return
    App(db).mainloop()
