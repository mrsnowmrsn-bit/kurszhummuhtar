/* ============================================================
   UniversityJournal: SQL Server дерекқоры (3НФ)
   Скрипт қайта іске қосуға болады (идемпотентті).
   Қолданба оны өзі орындайды; SSMS-те де ашып іске қосуға болады.
   ============================================================ */
IF DB_ID(N'UniversityJournal') IS NULL CREATE DATABASE UniversityJournal;
GO
USE UniversityJournal;
GO

/* ---------------- КЕСТЕЛЕР ---------------- */
IF OBJECT_ID(N'dbo.app_meta', N'U') IS NULL
CREATE TABLE dbo.app_meta (
    meta_key   NVARCHAR(50)  NOT NULL PRIMARY KEY,
    meta_value NVARCHAR(100) NOT NULL
);
GO
IF OBJECT_ID(N'dbo.users', N'U') IS NULL
CREATE TABLE dbo.users (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    username        NVARCHAR(50)  NOT NULL UNIQUE,
    password_hash   NVARCHAR(300) NOT NULL,
    full_name       NVARCHAR(150) NOT NULL,
    user_role       NVARCHAR(10)  NOT NULL
        CHECK (user_role IN (N'ADMIN', N'TEACHER', N'STUDENT')),
    failed_attempts INT NOT NULL DEFAULT 0,
    locked_until    DATETIME2 NULL
);
GO
IF OBJECT_ID(N'dbo.study_groups', N'U') IS NULL
CREATE TABLE dbo.study_groups (
    id         INT IDENTITY(1,1) PRIMARY KEY,
    group_name NVARCHAR(50) NOT NULL UNIQUE
);
GO
IF OBJECT_ID(N'dbo.subjects', N'U') IS NULL
CREATE TABLE dbo.subjects (
    id           INT IDENTITY(1,1) PRIMARY KEY,
    subject_name NVARCHAR(150) NOT NULL UNIQUE,
    credits      INT NOT NULL DEFAULT 3 CHECK (credits BETWEEN 1 AND 10)
);
GO
IF OBJECT_ID(N'dbo.students', N'U') IS NULL
CREATE TABLE dbo.students (
    id           INT IDENTITY(1,1) PRIMARY KEY,
    user_id      INT NULL,
    student_code NVARCHAR(20)  NOT NULL UNIQUE,
    full_name    NVARCHAR(150) NOT NULL,
    group_id     INT NOT NULL,
    course_num   INT NOT NULL CHECK (course_num BETWEEN 1 AND 5),
    CONSTRAINT fk_students_user  FOREIGN KEY (user_id)  REFERENCES dbo.users(id) ON DELETE SET NULL,
    CONSTRAINT fk_students_group FOREIGN KEY (group_id) REFERENCES dbo.study_groups(id)
);
GO
IF OBJECT_ID(N'dbo.teaching_assignments', N'U') IS NULL
CREATE TABLE dbo.teaching_assignments (
    id         INT IDENTITY(1,1) PRIMARY KEY,
    teacher_id INT NOT NULL,
    subject_id INT NOT NULL,
    group_id   INT NOT NULL,
    CONSTRAINT uq_assignment UNIQUE (teacher_id, subject_id, group_id),
    CONSTRAINT fk_ta_teacher FOREIGN KEY (teacher_id) REFERENCES dbo.users(id) ON DELETE CASCADE,
    CONSTRAINT fk_ta_subject FOREIGN KEY (subject_id) REFERENCES dbo.subjects(id) ON DELETE CASCADE,
    CONSTRAINT fk_ta_group   FOREIGN KEY (group_id)   REFERENCES dbo.study_groups(id) ON DELETE CASCADE
);
GO
IF OBJECT_ID(N'dbo.grades', N'U') IS NULL
CREATE TABLE dbo.grades (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    student_id  INT NOT NULL,
    subject_id  INT NOT NULL,
    grade       INT NULL CHECK (grade BETWEEN 0 AND 100),
    attendance  NVARCHAR(20) NOT NULL
        CHECK (attendance IN (N'Қатысты', N'Қатыспады', N'Себепті')),
    lesson_date DATE NOT NULL,
    CONSTRAINT uq_grade_lesson UNIQUE (student_id, subject_id, lesson_date),
    CONSTRAINT fk_grades_student FOREIGN KEY (student_id) REFERENCES dbo.students(id) ON DELETE CASCADE,
    CONSTRAINT fk_grades_subject FOREIGN KEY (subject_id) REFERENCES dbo.subjects(id) ON DELETE CASCADE
);
GO
IF OBJECT_ID(N'dbo.timetable', N'U') IS NULL
CREATE TABLE dbo.timetable (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    group_id    INT NOT NULL,
    subject_id  INT NOT NULL,
    day_of_week NVARCHAR(20) NOT NULL,
    time_slot   NVARCHAR(30) NOT NULL,
    room        NVARCHAR(30) NULL,
    CONSTRAINT fk_tt_group   FOREIGN KEY (group_id)   REFERENCES dbo.study_groups(id) ON DELETE CASCADE,
    CONSTRAINT fk_tt_subject FOREIGN KEY (subject_id) REFERENCES dbo.subjects(id) ON DELETE CASCADE
);
GO
IF OBJECT_ID(N'dbo.homeworks', N'U') IS NULL
CREATE TABLE dbo.homeworks (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    subject_id  INT NOT NULL,
    group_id    INT NOT NULL,
    title       NVARCHAR(200) NOT NULL,
    description NVARCHAR(MAX) NULL,
    deadline    DATE NULL,
    CONSTRAINT fk_hw_subject FOREIGN KEY (subject_id) REFERENCES dbo.subjects(id) ON DELETE CASCADE,
    CONSTRAINT fk_hw_group   FOREIGN KEY (group_id)   REFERENCES dbo.study_groups(id) ON DELETE CASCADE
);
GO
IF OBJECT_ID(N'dbo.submissions', N'U') IS NULL
CREATE TABLE dbo.submissions (
    id           INT IDENTITY(1,1) PRIMARY KEY,
    homework_id  INT NOT NULL,
    student_id   INT NOT NULL,
    content      NVARCHAR(MAX) NOT NULL,
    submitted_at DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT uq_submission UNIQUE (homework_id, student_id),
    CONSTRAINT fk_sub_hw      FOREIGN KEY (homework_id) REFERENCES dbo.homeworks(id) ON DELETE CASCADE,
    CONSTRAINT fk_sub_student FOREIGN KEY (student_id)  REFERENCES dbo.students(id) ON DELETE CASCADE
);
GO
/* target_group_id = NULL -> барлығына арналған хабарландыру */
IF OBJECT_ID(N'dbo.announcements', N'U') IS NULL
CREATE TABLE dbo.announcements (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    title           NVARCHAR(200) NOT NULL,
    content         NVARCHAR(MAX) NOT NULL,
    target_group_id INT NULL,
    created_at      DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT fk_ann_group FOREIGN KEY (target_group_id) REFERENCES dbo.study_groups(id) ON DELETE CASCADE
);
GO
IF OBJECT_ID(N'dbo.audit_logs', N'U') IS NULL
CREATE TABLE dbo.audit_logs (
    id         INT IDENTITY(1,1) PRIMARY KEY,
    username   NVARCHAR(50)  NULL,
    action     NVARCHAR(400) NULL,
    created_at DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
GO

/* ---------------- ИНДЕКСТЕР ---------------- */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ux_students_user' AND object_id = OBJECT_ID(N'dbo.students'))
    CREATE UNIQUE INDEX ux_students_user ON dbo.students(user_id) WHERE user_id IS NOT NULL;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_students_group' AND object_id = OBJECT_ID(N'dbo.students'))
    CREATE INDEX ix_students_group ON dbo.students(group_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_grades_student' AND object_id = OBJECT_ID(N'dbo.grades'))
    CREATE INDEX ix_grades_student ON dbo.grades(student_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_grades_subject' AND object_id = OBJECT_ID(N'dbo.grades'))
    CREATE INDEX ix_grades_subject ON dbo.grades(subject_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_timetable_group' AND object_id = OBJECT_ID(N'dbo.timetable'))
    CREATE INDEX ix_timetable_group ON dbo.timetable(group_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_homeworks_group' AND object_id = OBJECT_ID(N'dbo.homeworks'))
    CREATE INDEX ix_homeworks_group ON dbo.homeworks(group_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_audit_created' AND object_id = OBJECT_ID(N'dbo.audit_logs'))
    CREATE INDEX ix_audit_created ON dbo.audit_logs(created_at);
GO

/* ---------------- БАСТАПҚЫ ДЕРЕКТЕР ---------------- */
IF NOT EXISTS (SELECT 1 FROM dbo.study_groups)
    INSERT INTO dbo.study_groups (group_name) VALUES (N'ИС-301');
IF NOT EXISTS (SELECT 1 FROM dbo.subjects)
    INSERT INTO dbo.subjects (subject_name, credits) VALUES
        (N'Microsoft SQL Server Деректер Қоры', 5),
        (N'Веб-бағдарламалау', 4),
        (N'Алгоритмдер мен деректер құрылымы', 4),
        (N'Python бағдарламалау', 5);
GO

/* ---------------- ФУНКЦИЯ ---------------- */
CREATE OR ALTER FUNCTION dbo.fn_GradePoints (@grade INT)
RETURNS DECIMAL(2,1)
AS
BEGIN
    RETURN CASE WHEN @grade >= 90 THEN 4.0
                WHEN @grade >= 75 THEN 3.0
                WHEN @grade >= 50 THEN 2.0
                ELSE 1.0 END;
END
GO

/* ---------------- VIEW-лар ---------------- */
CREATE OR ALTER VIEW dbo.v_journal AS
SELECT g.id AS grade_id, st.id AS student_id, st.student_code, st.full_name,
       gr.id AS group_id, gr.group_name, sub.id AS subject_id, sub.subject_name,
       sub.credits, g.grade, g.attendance, g.lesson_date
FROM dbo.grades g
JOIN dbo.students st    ON st.id = g.student_id
JOIN dbo.study_groups gr ON gr.id = st.group_id
JOIN dbo.subjects sub   ON sub.id = g.subject_id;
GO
CREATE OR ALTER VIEW dbo.v_student_stats AS
SELECT st.id AS student_id, st.student_code, st.full_name, gr.group_name,
       COUNT(g.id) AS records,
       CAST(AVG(CAST(g.grade AS DECIMAL(5,2))) AS DECIMAL(5,1)) AS avg_grade,
       CAST(100.0 * SUM(CASE WHEN g.attendance = N'Қатысты' THEN 1 ELSE 0 END)
            / NULLIF(COUNT(g.id), 0) AS DECIMAL(5,0)) AS attendance_pct
FROM dbo.students st
JOIN dbo.study_groups gr ON gr.id = st.group_id
LEFT JOIN dbo.grades g   ON g.student_id = st.id
GROUP BY st.id, st.student_code, st.full_name, gr.group_name;
GO
CREATE OR ALTER VIEW dbo.v_student_gpa AS
SELECT g.student_id,
       CAST(SUM(dbo.fn_GradePoints(g.grade) * s.credits) * 1.0
            / NULLIF(SUM(s.credits), 0) AS DECIMAL(4,2)) AS gpa
FROM dbo.grades g
JOIN dbo.subjects s ON s.id = g.subject_id
WHERE g.grade IS NOT NULL
GROUP BY g.student_id;
GO

/* ---------------- САҚТАЛАТЫН ПРОЦЕДУРАЛАР ---------------- */
CREATE OR ALTER PROCEDURE dbo.sp_RegisterUser
    @username NVARCHAR(50), @password_hash NVARCHAR(300), @full_name NVARCHAR(150),
    @user_role NVARCHAR(10), @group_id INT = NULL, @course_num INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM dbo.users WHERE username = @username)
        THROW 50001, N'Бұл пайдаланушы аты бос емес.', 1;
    IF @user_role = N'STUDENT' AND (@group_id IS NULL OR @course_num IS NULL)
        THROW 50002, N'Студент үшін топ пен курс керек.', 1;
    BEGIN TRY
        BEGIN TRANSACTION;
        INSERT INTO dbo.users (username, password_hash, full_name, user_role)
        VALUES (@username, @password_hash, @full_name, @user_role);
        DECLARE @uid INT = SCOPE_IDENTITY();
        IF @user_role = N'STUDENT'
            INSERT INTO dbo.students (user_id, student_code, full_name, group_id, course_num)
            VALUES (@uid, CONCAT(N'ST-', FORMAT(@uid, '0000')), @full_name, @group_id, @course_num);
        INSERT INTO dbo.audit_logs (username, action)
        VALUES (@username, CONCAT(N'Тіркелді: ', @user_role));
        COMMIT TRANSACTION;
        SELECT @uid AS user_id;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO
CREATE OR ALTER PROCEDURE dbo.sp_GetUser @username NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT id, username, password_hash, full_name, user_role,
           CAST(CASE WHEN locked_until IS NOT NULL AND locked_until > SYSDATETIME()
                     THEN 1 ELSE 0 END AS INT) AS is_locked,
           ISNULL(DATEDIFF(MINUTE, SYSDATETIME(), locked_until), 0) AS minutes_left
    FROM dbo.users WHERE username = @username;
END
GO
CREATE OR ALTER PROCEDURE dbo.sp_LoginFailed @user_id INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @n INT;
    SELECT @n = CASE WHEN locked_until IS NOT NULL AND locked_until < SYSDATETIME()
                     THEN 0 ELSE failed_attempts END + 1
    FROM dbo.users WHERE id = @user_id;
    UPDATE dbo.users
       SET failed_attempts = @n,
           locked_until = CASE WHEN @n >= 5 THEN DATEADD(MINUTE, 10, SYSDATETIME()) ELSE NULL END
     WHERE id = @user_id;
    INSERT INTO dbo.audit_logs (username, action)
    SELECT username, N'Кіру сәтсіз' FROM dbo.users WHERE id = @user_id;
END
GO
CREATE OR ALTER PROCEDURE dbo.sp_LoginOk @user_id INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.users SET failed_attempts = 0, locked_until = NULL WHERE id = @user_id;
    INSERT INTO dbo.audit_logs (username, action)
    SELECT username, N'Жүйеге кірді' FROM dbo.users WHERE id = @user_id;
END
GO
CREATE OR ALTER PROCEDURE dbo.sp_ChangePassword @user_id INT, @password_hash NVARCHAR(300)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.users SET password_hash = @password_hash, failed_attempts = 0, locked_until = NULL
     WHERE id = @user_id;
    IF @@ROWCOUNT = 0 THROW 50004, N'Пайдаланушы табылмады.', 1;
END
GO
CREATE OR ALTER PROCEDURE dbo.sp_UpdateStudent
    @student_id INT, @full_name NVARCHAR(150), @group_id INT, @course_num INT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.students WHERE id = @student_id)
        THROW 50003, N'Студент табылмады.', 1;
    BEGIN TRY
        BEGIN TRANSACTION;
        UPDATE dbo.students SET full_name = @full_name, group_id = @group_id,
               course_num = @course_num WHERE id = @student_id;
        UPDATE u SET u.full_name = @full_name
          FROM dbo.users u JOIN dbo.students s ON s.user_id = u.id
         WHERE s.id = @student_id;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO
CREATE OR ALTER PROCEDURE dbo.sp_DeleteStudent @student_id INT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.students WHERE id = @student_id)
        THROW 50003, N'Студент табылмады.', 1;
    DECLARE @uid INT = (SELECT user_id FROM dbo.students WHERE id = @student_id);
    BEGIN TRY
        BEGIN TRANSACTION;
        DELETE FROM dbo.students WHERE id = @student_id;
        IF @uid IS NOT NULL DELETE FROM dbo.users WHERE id = @uid;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO
CREATE OR ALTER PROCEDURE dbo.sp_SetGrade
    @student_id INT, @subject_id INT, @grade INT, @attendance NVARCHAR(20),
    @lesson_date DATE, @teacher_id INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    /* Оқытушы тек өзіне тағайындалған пән/топқа баға қоя алады */
    IF @teacher_id IS NOT NULL AND NOT EXISTS (
        SELECT 1 FROM dbo.teaching_assignments ta
        JOIN dbo.students s ON s.group_id = ta.group_id
        WHERE ta.teacher_id = @teacher_id AND ta.subject_id = @subject_id
          AND s.id = @student_id)
        THROW 50010, N'Бұл пән/топқа баға қоюға құқығыңыз жоқ.', 1;
    DECLARE @updated INT = 0;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF EXISTS (SELECT 1 FROM dbo.grades WHERE student_id = @student_id
                   AND subject_id = @subject_id AND lesson_date = @lesson_date)
        BEGIN
            UPDATE dbo.grades SET grade = @grade, attendance = @attendance
             WHERE student_id = @student_id AND subject_id = @subject_id
               AND lesson_date = @lesson_date;
            SET @updated = 1;
        END
        ELSE
            INSERT INTO dbo.grades (student_id, subject_id, grade, attendance, lesson_date)
            VALUES (@student_id, @subject_id, @grade, @attendance, @lesson_date);
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
    SELECT @updated AS updated;
END
GO
CREATE OR ALTER PROCEDURE dbo.sp_DeleteGrade @grade_id INT, @teacher_id INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @teacher_id IS NOT NULL AND NOT EXISTS (
        SELECT 1 FROM dbo.grades g
        JOIN dbo.students s ON s.id = g.student_id
        JOIN dbo.teaching_assignments ta
          ON ta.group_id = s.group_id AND ta.subject_id = g.subject_id
        WHERE g.id = @grade_id AND ta.teacher_id = @teacher_id)
        THROW 50010, N'Бұл жазбаны жоюға құқығыңыз жоқ.', 1;
    DELETE FROM dbo.grades WHERE id = @grade_id;
END
GO
CREATE OR ALTER PROCEDURE dbo.sp_SubmitHomework
    @homework_id INT, @student_id INT, @content NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    /* Студент тек өз тобына берілген тапсырманы тапсыра алады */
    IF NOT EXISTS (SELECT 1 FROM dbo.homeworks h JOIN dbo.students s ON s.group_id = h.group_id
                   WHERE h.id = @homework_id AND s.id = @student_id)
        THROW 50011, N'Бұл тапсырма сіздің тобыңызға берілмеген.', 1;
    IF EXISTS (SELECT 1 FROM dbo.submissions WHERE homework_id = @homework_id AND student_id = @student_id)
        UPDATE dbo.submissions SET content = @content, submitted_at = SYSDATETIME()
         WHERE homework_id = @homework_id AND student_id = @student_id;
    ELSE
        INSERT INTO dbo.submissions (homework_id, student_id, content)
        VALUES (@homework_id, @student_id, @content);
END
GO
CREATE OR ALTER PROCEDURE dbo.sp_BackupDatabase @path NVARCHAR(400)
AS
BEGIN
    SET NOCOUNT ON;
    BACKUP DATABASE UniversityJournal TO DISK = @path WITH INIT;
    INSERT INTO dbo.audit_logs (username, action)
    VALUES (CAST(SESSION_CONTEXT(N'username') AS NVARCHAR(50)), N'Сақтық көшірме жасалды');
END
GO

/* ---------------- ТРИГГЕРЛЕР ---------------- */
/* 1) Бағалардың кез келген өзгерісі аудитке жазылады */
CREATE OR ALTER TRIGGER dbo.trg_grades_audit ON dbo.grades
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @u NVARCHAR(50) = COALESCE(CAST(SESSION_CONTEXT(N'username') AS NVARCHAR(50)),
                                       CAST(SUSER_SNAME() AS NVARCHAR(50)));
    INSERT INTO dbo.audit_logs (username, action)
    SELECT @u, CONCAT(N'Баға сақталды: студент=', i.student_id, N', пән=', i.subject_id,
                      N', баға=', i.grade)
    FROM inserted i;
    INSERT INTO dbo.audit_logs (username, action)
    SELECT @u, CONCAT(N'Баға жойылды: студент=', d.student_id, N', пән=', d.subject_id)
    FROM deleted d
    WHERE NOT EXISTS (SELECT 1 FROM inserted i WHERE i.id = d.id);
END
GO
/* 2) Студент жойылса, аудитке жазылады */
CREATE OR ALTER TRIGGER dbo.trg_students_audit ON dbo.students
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.audit_logs (username, action)
    SELECT COALESCE(CAST(SESSION_CONTEXT(N'username') AS NVARCHAR(50)),
                    CAST(SUSER_SNAME() AS NVARCHAR(50))),
           CONCAT(N'Студент жойылды: ', d.student_code, N' ', d.full_name)
    FROM deleted d;
END
GO
/* 3) Соңғы әкімшіні жоюға тыйым */
CREATE OR ALTER TRIGGER dbo.trg_users_keep_admin ON dbo.users
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.users WHERE user_role = N'ADMIN')
    BEGIN
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW 50030, N'Соңғы әкімшіні жоюға болмайды.', 1;
    END
END
GO

IF EXISTS (SELECT 1 FROM dbo.app_meta WHERE meta_key = N'schema_version')
    UPDATE dbo.app_meta SET meta_value = N'3' WHERE meta_key = N'schema_version';
ELSE
    INSERT INTO dbo.app_meta (meta_key, meta_value) VALUES (N'schema_version', N'3');
GO
