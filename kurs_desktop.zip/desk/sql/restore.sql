/* Қалпына келтіру (SSMS-те іске қосыңыз). Файл жолын өзгертіңіз. */
USE master;
GO
ALTER DATABASE UniversityJournal SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
RESTORE DATABASE UniversityJournal
    FROM DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\Backup\UniversityJournal_20260101_120000.bak'
    WITH REPLACE;
ALTER DATABASE UniversityJournal SET MULTI_USER;
GO
