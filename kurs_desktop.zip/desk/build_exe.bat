@echo off
chcp 65001 >nul
cd /d %~dp0
py -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt pyinstaller
.venv\Scripts\pyinstaller --noconfirm --onedir --windowed --name UniversityJournal ^
  --collect-all customtkinter ^
  --hidden-import matplotlib.backends.backend_tkagg ^
  --add-data "sql;sql" main.py
copy /Y config.ini dist\UniversityJournal\config.ini
echo.
echo Дайын: dist\UniversityJournal\UniversityJournal.exe
echo Бүкіл dist\UniversityJournal қалтасын көшіріңіз.
pause
